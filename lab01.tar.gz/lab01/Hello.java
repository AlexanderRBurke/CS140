package lab01; // bundled in package based on name of assignment/lab

// class name must match file name
public class Hello {
    // main method called implicity when you run program
    public static void main(String[] args) {
        System.out.println("Hello, World!"); // print out text
    }
}
