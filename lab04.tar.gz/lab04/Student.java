package lab04;

import java.util.ArrayList;
import java.util.List;
import java.util.Arrays;

public class Student{

	private int id;
	private String name;

	Student(int id, String name){
		this.id = id;
		this.name = name;	
	}
	
	public int getID(){
		return id;	
	}
	public String getName(){
		return 	name;	
	}



}




